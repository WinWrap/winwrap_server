﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace winwrap_edit_server
{
    public static class Secret
    {
        public const string MySecret = "00000000-0000-0000-0000-000000000000"; 
    }
}
